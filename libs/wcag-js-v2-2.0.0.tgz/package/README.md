# WCAG Checker Implementation

Accessibility (axe-core) and page-level performance (Google Lighthouse) auditing
for **Playwright** test suites. Ships as the npm package `wcag-js-v2`.

## Prerequisites

- Node.js 22.19 or newer (Lighthouse 13 requirement)
- Google Chrome (Lighthouse launches it through `chrome-launcher`)
- `@playwright/test` (or `playwright-core`) in the consuming project

## Installation

The package is not published publicly; install it from the built tarball:

```json
"dependencies": {
  "wcag-js-v2": "file:libs/wcag-js-v2-2.0.0.tgz"
}
```

```javascript
import {
  init,
  analyse,
  getHtmlReportByCategory,
  getHtmlReportByGuideLine,
  getJsonReport,
  getHtmlPerformanceMetrics,
} from 'wcag-js-v2';
```

## Usage

### 1. Initialise the checker

Call `init()` once per run, in `beforeAll`:

```javascript
await init();
```

### 2. Analyse a page

`analyse()` runs Lighthouse and axe-core against the current page. Pass the
Playwright `Page` as the first argument; the optional second argument keys the
result when the same URL is audited more than once:

```javascript
await page.goto(url);
await analyse(page);          // or analyse(page, 'state-name')
```

### 3. Generate reports

Call the report getters at the end of the run (`afterAll`). Results are held in
memory for the current process, so write the reports in the same worker that ran
the audits:

```javascript
await fs.writeFile('reports/accessibility_category_latest.html', await getHtmlReportByCategory());
await fs.writeFile('reports/accessibility_guideline_latest.html', await getHtmlReportByGuideLine());
await fs.writeFile('reports/accessibility_json_report_latest.json', await getJsonReport());
await fs.writeFile('reports/performance_html_report_latest.html', await getHtmlPerformanceMetrics());
```

## API

| Export | Purpose |
| --- | --- |
| `init()` | Start a report run, records the start time |
| `analyse(page, pageKey?)` | Lighthouse + axe-core audit of the current page |
| `getJsonReport()` | `{ overview, summary, details }` JSON string |
| `getHtmlReportByCategory()` | HTML report grouped by issue category |
| `getHtmlReportByGuideLine()` | HTML report grouped by WCAG guideline |
| `getHtmlPerformanceMetrics()` | Lighthouse performance/SEO dashboard |
| `scanPage(page, config, defaults)` | Raw axe-core scan without Lighthouse |
| `runLighthouseAudit(url, name, options)` | Lighthouse run returning summary, HTML and LHR |

## Package contents

The published tarball contains only the compiled bundle and its metadata:

```
dist/index.js     # bundled ESM entry point (all library modules, minified)
package.json
README.md
```

Nothing from `src/`, `tests/`, `demo/`, `scripts/` or the build/lint configuration
is included:

- `package.json` allow-lists the package with `"files": ["dist"]`, so anything
  outside `dist/` is never packed.
- `build.js` bundles a single entry (`src/index.js`); esbuild only follows the
  imports reachable from that entry. Nothing in `src/` imports `tests/`, `demo/`
  or the dev scripts, so they cannot end up in the bundle.

Inspect the contents before publishing:

```bash
npm run build
npm pack --dry-run
```

## Development

Plain JavaScript (ES modules) — no TypeScript, no build step for consumers.

```bash
npm install
npm run check   # node --check on every source module
npm run lint    # eslint with the security plugins
npm run build   # bundles src/index.js into minified dist/index.js
npm pack        # produces wcag-js-v2-<version>.tgz (dist + package.json + README only)
```

Update the version in the consuming project's `package.json`, drop the new
tarball into its `libs/` folder and run `npm install`.
